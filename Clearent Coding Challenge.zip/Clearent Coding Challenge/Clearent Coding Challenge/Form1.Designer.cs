﻿namespace Clearent_Coding_Challenge
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.testCase1 = new System.Windows.Forms.CheckBox();
            this.testCase2 = new System.Windows.Forms.CheckBox();
            this.testCase3 = new System.Windows.Forms.CheckBox();
            this.testCaseBox = new System.Windows.Forms.GroupBox();
            this.calculate = new System.Windows.Forms.Button();
            this.interestLabel = new System.Windows.Forms.Label();
            this.testCaseBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // testCase1
            // 
            this.testCase1.AutoSize = true;
            this.testCase1.Location = new System.Drawing.Point(6, 19);
            this.testCase1.Name = "testCase1";
            this.testCase1.Size = new System.Drawing.Size(83, 17);
            this.testCase1.TabIndex = 0;
            this.testCase1.Text = "Test Case 1";
            this.testCase1.UseVisualStyleBackColor = true;
            this.testCase1.CheckedChanged += new System.EventHandler(this.testCase1_CheckedChanged);
            // 
            // testCase2
            // 
            this.testCase2.AutoSize = true;
            this.testCase2.Location = new System.Drawing.Point(0, 76);
            this.testCase2.Name = "testCase2";
            this.testCase2.Size = new System.Drawing.Size(83, 17);
            this.testCase2.TabIndex = 1;
            this.testCase2.Text = "Test Case 2";
            this.testCase2.UseVisualStyleBackColor = true;
            // 
            // testCase3
            // 
            this.testCase3.AutoSize = true;
            this.testCase3.Location = new System.Drawing.Point(6, 147);
            this.testCase3.Name = "testCase3";
            this.testCase3.Size = new System.Drawing.Size(83, 17);
            this.testCase3.TabIndex = 2;
            this.testCase3.Text = "Test Case 3";
            this.testCase3.UseVisualStyleBackColor = true;
            // 
            // testCaseBox
            // 
            this.testCaseBox.Controls.Add(this.testCase1);
            this.testCaseBox.Controls.Add(this.testCase3);
            this.testCaseBox.Controls.Add(this.testCase2);
            this.testCaseBox.Location = new System.Drawing.Point(12, 49);
            this.testCaseBox.Name = "testCaseBox";
            this.testCaseBox.Size = new System.Drawing.Size(121, 183);
            this.testCaseBox.TabIndex = 3;
            this.testCaseBox.TabStop = false;
            this.testCaseBox.Text = "Test Cases:";
            // 
            // calculate
            // 
            this.calculate.Location = new System.Drawing.Point(34, 249);
            this.calculate.Name = "calculate";
            this.calculate.Size = new System.Drawing.Size(149, 65);
            this.calculate.TabIndex = 4;
            this.calculate.Text = "Calculate Interest:";
            this.calculate.UseVisualStyleBackColor = true;
            this.calculate.Click += new System.EventHandler(this.calculate_Click);
            // 
            // interestLabel
            // 
            this.interestLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.interestLabel.Location = new System.Drawing.Point(209, 249);
            this.interestLabel.Name = "interestLabel";
            this.interestLabel.Size = new System.Drawing.Size(283, 126);
            this.interestLabel.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.interestLabel);
            this.Controls.Add(this.calculate);
            this.Controls.Add(this.testCaseBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.testCaseBox.ResumeLayout(false);
            this.testCaseBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox testCase1;
        private System.Windows.Forms.CheckBox testCase2;
        private System.Windows.Forms.CheckBox testCase3;
        private System.Windows.Forms.GroupBox testCaseBox;
        private System.Windows.Forms.Button calculate;
        private System.Windows.Forms.Label interestLabel;
    }
}

