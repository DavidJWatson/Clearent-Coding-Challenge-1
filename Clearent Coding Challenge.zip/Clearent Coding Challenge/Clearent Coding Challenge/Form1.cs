﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clearent_Coding_Challenge
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void testCase1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void calculate_Click(object sender, EventArgs e)
        {
            double Visa;
            double MasterCard;
            double Discover;
            double wallet1;
            double wallet2;
            double person1;
            double person2; 
            double totalInterest;
            
            Visa = .10 * 100;
            MasterCard = .05 * 100;
            Discover = .01 * 100;

            if (testCase1.Checked)
            {
                totalInterest = Visa + MasterCard + Discover;
                interestLabel.Text = "The total interest for the Visa is " + Visa.ToString("n1") +
                    "the total interest for the Mastercard is " + MasterCard.ToString("n1") +
                    "the total interest for the Discover is " + Discover.ToString("n1") +
                    "for a total interest of " + totalInterest.ToString("n1");                    
            }
            else if (testCase2.Checked)
            {
                wallet1 = Visa + Discover;
                wallet2 = MasterCard;
                totalInterest = wallet1 + wallet2;
                interestLabel.Text = "The total interest for wallet 1 is"
                    + wallet1.ToString("n1") + "and the total interest for wallet 2 is" + wallet2.ToString("n1") +
                    "for a total interest of" + totalInterest.ToString("n1");
            }
            else if (testCase3.Checked)
            {
                person1 = MasterCard+Visa;
                person2 = Visa + MasterCard;
                interestLabel.Text = "The total interest for wallet (and person) 1 is" + person1.ToString("n1")
                    + "and the total interest for wallet (and person) 2 is" + person2.ToString("n2"); 
            }
        
        }
    }
}
